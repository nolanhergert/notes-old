function [score,g] = criterion(a)
%%% optimization criterion: p is vector of joint angles

global target;
global tree;
global diffs;
global angles;

for i = 1:length(a)
    tree.j(i).angle = a(i);
end
[ tree1 robot_com robot_mass ] = drc_forward_kinematics( tree );
draw(tree1, target, robot_com);

score = (tree1.j(29).position - target)*(tree1.j(29).position - target)';
if nargout > 1
    %Compute the gradient analytically based on joint angles
    result = subs(diffs,angles,a);
    %Return the normalized gradient using x,y,z axes
    g = sqrt(sum(result.^2,2))
    
end
% final end
end
