function result = draw( tree, target, robot_com )
% draw( tree ), return value is meaningless


for i = 2:29
 x(1) = tree.j(i).position(1);
 y(1) = tree.j(i).position(2);
 z(1) = tree.j(i).position(3);
 ii = tree.l(i).parent;
 x(2) = tree.j(ii).position(1);
 y(2) = tree.j(ii).position(2);
 z(2) = tree.j(ii).position(3);
 if (i == 17)
     plot3(x,y,z,'*-k');
 else
    plot3( x, y, z,'.-b' )
 end
 hold on
end
if (exist('target','var') ~= 0)
    plot3(target(1),target(2),target(3),'*r');
end
if (exist('robot_com','var') ~= 0) 
    plot3(robot_com(1),robot_com(2),0,'og');
end
%Draw center-of-mass bounding box
box = [.302/2,.262/2,0; ...
       -.302/2,.262/2,0; ...
       -.302/2,-.262/2,0; ...
       .302/2,-.262/2,0; ...
       .302/2,.262/2,0];
plot3(box(:,1),box(:,2),box(:,3),'g-');
grid on
axis( [-1 1 -1 1 0 2 ] );

hold off
drawnow;