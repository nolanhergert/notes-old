%%% constraints for optimizing 3 joint inverse kinematics
function [ineq_violations,eq_violations]=constraints(a)
%don't use a for now, since tree should have been updated already?

global tree;
tree1 = tree;
for i = 1:length(a)
    tree1.j(i).angle = a(i);
end
[ tree2 robot_com robot_mass ] = drc_forward_kinematics( tree1 );   

%Feet cannot move
eq_violations = [];
%eq_violations(1) = (tree2.j(17).position - [-0.0484 -0.0890 0.0811])*(tree2.j(17).position - [-0.0484 -0.0890 0.0811])';

eq_violations(1:3) = (tree2.j(17).position - [-0.0484 -0.0890 0.0811]);


%Robot center of mass should not go outside of rectangle
ineq_violations(1) = abs(robot_com(1)) - .302/2;
ineq_violations(2) = abs(robot_com(2)) - .262/2;


end
%% final end