% main to run drc robot with constraints for right wrist to touch 
% a target point

%%%%%%%%%%%%%% SHOULD WE PROVIDE AN ANALYTIC GRADIENT??? %%%%%%%%%%%%%%%%
computeGradient = 0; %0 or 1

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global target;
target          = [ 0  -0.043  0.8];
global tree;


% load robot
drc

[ tree1 robot_com robot_mass ] = drc_forward_kinematics( tree );
draw(tree1, target);

% set options for fmincon()
if (computeGradient == 1)
    [tree1 robot_com robot_mass] = drc_forward_kinematics_symbolic(tree);
    options = optimset('Display','iter','MaxFunEvals',1000000,'GradObj','on');
else
    options = optimset('Display','iter','MaxFunEvals',1000000);
end

for i = 1:29
    a(i) = tree.j(i).angle;
end
% do optimization
[answer,fval,exitflag]=fmincon(@criterion,a,[],[],[],[],[],[],@constraints,options);

answer
fval
exitflag
