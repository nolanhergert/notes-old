Parallel Tracking and Multiple Mapping (PTAMM) README
-----------------------------------------------------

Please see the manual.pdf for complete installation and usage instructions.

-- EOF --