'''
Other options include:

  * Estimate future trajectory of object using KF
  * Track if background changed in the region
  * More at: http://en.wikipedia.org/wiki/Video_tracking??
  
'''
