
# Run tesseract
print subprocess.call('tesseract ' + filename + ' out',shell=True)
